//
//  ViewController.swift
//  MyFirstApp
//
//  Created by Grecia  on 22/09/23.
//

import UIKit

class MainViewController: UIViewController {
    
    @IBOutlet weak var photoTypeSwitch: UISwitch!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var titleTextField: UITextField! {
        didSet {
            titleTextField.delegate = self
        }
    }
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var customTitleSwitch: UISwitch!
    
    @IBAction func photoTypeSwitchValueChanged(_ sender: UISwitch) {
        sender.isOn ? nextButton.setTitle("Cats", for: .normal) : nextButton.setTitle("Dogs", for: .normal)
    }
    
    @IBAction func customTitleSwitchValueChanged(_ sender: UISwitch) {
        titleLabel.text = sender.isOn ? titleTextField.text : "Custom title not enabled"
        titleTextField.isEnabled = sender.isOn
    }
    
    @IBAction func titleTextFieldEditingChanged(_ sender: UITextField) {
        titleLabel.text = sender.text
    }
    
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        if sender.tag == 0 {
            segueToInfo()
        } else {
            segueToPhotos()
        }
    }
    
    func segueToInfo() {
        let infoViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InfoViewController")
        infoViewController.title = "Info"
        navigationController?.pushViewController(infoViewController, animated: true)
    }
    
    func segueToPhotos() {
        guard let photosViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ImageStackViewController") as? ImageStackViewController else { return }
        photosViewController.showCat = photoTypeSwitch.isOn
        if customTitleSwitch.isOn {
            photosViewController.title = titleTextField.text
        }
        navigationController?.pushViewController(photosViewController, animated: true)
    }
    
}


extension MainViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string == "" { return true }
        if string.rangeOfCharacter(from: .alphanumerics) == nil && string != " " {
            return false
        } else {
            return (textField.text?.count ?? 0) + string.count - range.length <= 10
        }
    }
    
}
